% Bildverarbeitung Uebung 4
% Ziqing Yu 3218051

clc
% clear all;
close all;

% Vordefinieren
name1 = 'DSC_0187.jpg';
name2 = 'DSC_0188.jpg';
name3 = 'DBV_2019_1.jpg';
name4 = 'DBV_2019_2.jpg';

% Funktion anrufen
diff1 = Projektive(name1,name2);
diff2 = Projektive(name3,name4);

function [f] = Projektive(name1,name2)
    % Daten lesen
    I1 = imread(name1);
    I2 = imread(name2);

    % identische Punkte
    figure, imshow(I1);
    hold on
    [x1,y1] = getline('closed');
    scatter(x1,y1,'p','r');
    x1 = x1(1:end-1);
    y1 = y1(1:end-1);

    figure, imshow(I2);
    hold on
    [x2,y2] = getline('closed');
    scatter(x2,y2,'p','r');
    x2 = x2(1:end-1);
    y2 = y2(1:end-1);

    % ueberpruefen
    if length(x1) ~= length(x2)
        error('Anzahl der Punkten nicht identisch!')
    end


    %% 
    % homogene Punkte
    p1 = [x1,y1,ones(length(x1),1)];
    p2 = [x2,y2,ones(length(x2),1)];

    A = zeros(2 * length(1),9);
    O = [0 0 0];

    for n = 1:length(x1)
        X = p1(n,:);
        x = p2(n,1);
        y = p2(n,2);
        w = p2(n,3);
        A(2 * n - 1, :) = [O, -w * X, y * X];
        A(2 * n, :) = [w * X, O, -x * X];
    end

    % Sigulaerwerte
    [U,D,V] = svd(A);
    H = reshape(V(:,9),3,3)';

    figure;
    h_0 = imshow([I1, I2]);
    title('Originalbilder mit gewealten Punkten')
    hold on;
    diff = length(I1);
    line([p1(:,1),p2(:,1)+diff]',[p1(:,2),p2(:,2)]');
    hold off;

    % Transformation
    [width,height,~] = size(I1);

    % Matrix mit Pixelkoordinaten
    [x_i, y_i] = meshgrid(1:height, 1:width);
    TransPoints=[x_i(:),y_i(:),ones(length(y_i(:)),1)]';

    % Bildkoordinatentransformation
    pixel_pkt = H * TransPoints;

    % Pixelkoordinaten normieren
    pixel_pkt(1,:) = pixel_pkt(1,:)./pixel_pkt(3,:);
    pixel_pkt(2,:) = pixel_pkt(2,:)./pixel_pkt(3,:);
    pixel_pkt(3,:) = [];
    
    % Diff
    cal = H * p1';
    cal = cal ./ cal(3,:);
    f = p2' - cal; 
    
    % Transformiertpunkt in Zielbild
    figure,imshow(I2)
    hold on
    scatter(cal(1,:),cal(2,:),'r');
    scatter(p2(:,1),p2(:,2),'b');
    legend('transformiert','gew�hlt')
    hold off

    % Pixelkoordinaten zuruek in Matrixform 
    x_i = reshape(pixel_pkt(1,:),width,height);
    y_i = reshape(pixel_pkt(2,:),width,height);

    % Grauwertinterpolation
    Bildhsv_1 = rgb2hsv(I1);
    Bildgrauwert_1 = Bildhsv_1(:,:,3);
    Bildhsv_2 = rgb2hsv(I2);
    Bildgrauwert_2 = Bildhsv_2(:,:,3);


    % Interpolation 
    Bild_neu = interp2(double(Bildgrauwert_2),x_i,y_i,'linear',0);
    % Darstellung Originalbild neben transformiertem Bild
    figure
    imshow([Bildgrauwert_2, Bild_neu]);
    title('Originalbild und transformiertes Bild')

    % Bilder ueberlagern
    Bild_ueberlagert = (0.5 * Bild_neu + 0.5 * double(Bildgrauwert_1));

    % Darstellung des ueberlagerten Bildes (grau)
    figure
    imshow(Bild_ueberlagert); 
    title('ueberlagertes Bild');
    % Darstellung des ueberlagerten Bildes (farblich)
    Bild_neuf(:,:,1) = interp2(im2double(I2(:,:,1)),x_i,y_i,'linear',0);
    Bild_neuf(:,:,2) = interp2(im2double(I2(:,:,2)),x_i,y_i,'linear',0);
    Bild_neuf(:,:,3) = interp2(im2double(I2(:,:,3)),x_i,y_i,'linear',0);
    Bild_ueberlagert2 = (0.5 * Bild_neuf + 0.5 * im2double(I1));
    figure
    imshow(Bild_ueberlagert2); 
    title('ueberlagertes Bild (farblich)');
end
